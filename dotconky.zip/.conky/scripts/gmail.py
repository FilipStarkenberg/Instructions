import os
 
#Enter your username and password below within double quotes
# eg. username="username" and password="password"
username="xxxxxx"
password="xxxxxx"
com="wget -q -O - https://"+username+":"+password+"@mail.google.com/mail/feed/atom"

temp=os.popen(com)
msg=temp.read()
print(msg)
index=msg.find("<fullcount>")
index2=msg.find("</fullcount>")
fc=msg[index+11:index2]

if fc==0:
   print ("0")
else:
   print (str(fc))

